import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class LoginManager {
    private SQLiteDatabase database;

    public LoginManager(SQLiteDatabase database) {
        this.database = database;
    }

    public boolean authenticateUser(String username, String password) {
        String query = "SELECT * FROM Users WHERE username = ? AND password = ?";
        Cursor cursor = database.rawQuery(query, new String[]{username, password});
        boolean loggedIn = cursor.getCount() > 0;
        cursor.close();
        return loggedIn;
    }

    public void registerUser(String username, String password) {
        String insertQuery = "INSERT INTO Users (username, password) VALUES (?, ?)";
        database.execSQL(insertQuery, new String[]{username, password});
    }
}