//Karina Washington
//April 20th, 2024
//Project Three

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.projectthree.R;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private LoginManager loginManager;
    private DatabaseManager databaseManager;
    private NotificationManager notificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database manager
        databaseManager = new DatabaseManager(this);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        // Initialize login manager with database instance
        loginManager = new LoginManager(databaseManager.getReadableDatabase());
        notificationManager = new NotificationManager(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                // Check if the username and password are not empty
                if (!username.isEmpty() && !password.isEmpty()) {
                    // Authenticate the user
                    if (loginManager.authenticateUser(username, password)) {
                        // Show login success message
                        Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();

                        // Check and request SMS permission
                        if (checkAndRequestSmsPermission()) {
                            // Send SMS notification
                            notificationManager.sendSMS(username, "Login successful!");
                        }
                    } else {
                        // Show login failure message
                        Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Show message if username or password is empty
                    Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to check and request SMS permission
    private boolean checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
            return false;
        }
        // Permission is already granted
        return true;
    }

    // Handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send SMS notification
                String username = usernameEditText.getText().toString().trim();
                notificationManager.sendSMS(username, "Login successful!");
            } else {
                // Permission denied, show message
                Toast.makeText(this, "SMS permission denied. Notifications will not be sent.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}